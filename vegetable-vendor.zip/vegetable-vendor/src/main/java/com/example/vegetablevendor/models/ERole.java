package com.example.vegetablevendor.models;

public enum ERole {
  USER,
  ADMIN
}
