package com.example.vegetablevendor.payload.request;

import java.util.List;

import lombok.Data;

@Data
public class BookingItems {

    private List<String> id;
    
}
