package com.example.vegetablevendor.payload.response;

import lombok.Data;

@Data
public class MessageResponse {
	private String message;
}
